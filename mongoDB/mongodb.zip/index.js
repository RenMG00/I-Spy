const mongoose = require('mongoose');
const Books = require('./models/books');

let connection_string = "mongodb://127.0.0.1:27017/ren_personal_collection?retryWrites=true&w=majority";

mongoose.set('useUnifiedTopology', true);
mongoose.set('useCreateIndex', true);
mongoose.set('useFindAndModify', false);
mongoose.set('useNewUrlParser', true);

mongoose.connect(connection_string)
    .then(
        () => {
            console.log('Connection Successful!');

            find_all_books();
            update_one_book();
            //create_book();
            delete_fakebook();

        }
    )
    .catch(
        (error) => {
            console.log('An error has occured: ', error);
        }
    );
function delete_fakebook() {
    console.log('Deleting fake book Scrum Buddies using callback.');

    let book_id = '5e45e502bc7d17077c2d636d';
    Books.findByIdAndDelete(
        { _id: book_id },
        (err, deleted_book) => {
            if (err) {
                return console.log('Error.');
            }
            console.log(deleted_book);
        }
    )
}
function update_one_book() {
    console.log('Updating title of Fahrenheit 451 using a callback function.');

    let book_id = '5e45e4e1dd297504b08f3e73';
    Books.findOneAndUpdate(
        { _id: book_id },
        { title: 'Fahrenheit 451' },
        { new: true },
        (err, updated_book) => {
            if (err) {
                return console.log('Error.');
            }
            console.log(updated_book);
        }

    )
}
let books_query = Books.find({});
books_query.sort({ title: 1, author_name: 1 });
let find_promise = books_query.exec();
console.log('Is a Promise: ' + (find_promise instanceof Promise));
find_promise
    .then((books) => {
        books.map((books) => console.log(books.title));
        books.map((books) => console.log(books.author_name));
    })
    .catch((err) => {
        console.log('Error.')
    });

function find_all_books() {
    Books.find({}, (err, books) => {
        if (err) {
            return console.log('Error:', err);
        }
        console.log(books);
    })

}
function create_book() {
    console.log('Creating book test');

    const new_book = new Books({
        author_name: 'Ray Bradburry',
        author_age: 91,
        title: 'Fahrenheit_451',
        pubyear: 1953,
        category: 'Dystopian',
    });
    // Need to update title to remove _ from Fahrenheit_451.
    console.log('Creating fake book.')
    console.log('Creating other books.')

    new_book.author_name = 'Frank Herbert';
    new_book.author_age = 65;
    new_book.title = 'Dune';
    new_book.pubyear = 1965;
    new_book.category = 'Science Fiction';


    let save_promise = new_book.save();
    console.log('Is a promise: ' + (save_promise instanceof Promise));
    save_promise
        .then((saved_book) => {
            console.log('ID: ' + saved_book._id);
            console.log(saved_book);
        })
        .catch((err) => {
            console.log('Error: ', err);
        }
        )

};

